<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function eurcsol_MetaData()
{
    return array(
        'DisplayName' => 'eurcsol',
        'DisableLocalCreditCardInput' => true,
    );
}

function eurcsol_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'EURC Solana',
        ),
        'description' => array(
            'FriendlyName' => 'Description',
            'Type' => 'textarea',
            'Rows' => '3',
            'Cols' => '25',
            'Default' => 'Pay using crypto EURC Solana.',
            'Description' => 'This controls the description which the user sees during checkout.',
        ),
        'blockchain_fees' => array(
            'FriendlyName' => 'Customer pays blockchain fees',
            'Type' => 'yesno',
            'Description' => 'Add estimate blockchain fees to the invoice total.',
            'Default' => 'off',
        ),		
        'wallet_address' => array(
            'FriendlyName' => 'EURC Solana Wallet Address',
            'Type' => 'text',
            'Description' => 'Insert your sol-eurc Wallet address.',
        ),
    );
}

function eurcsol_link($params)
{
    $walletAddress = $params['wallet_address'];
    $amount = $params['amount'];
    $invoiceId = $params['invoiceid'];
    $systemUrl = rtrim($params['systemurl'], '/');
    $redirectUrl = $systemUrl . '/modules/gateways/callback/eurcsol.php';
	$invoiceLink = $systemUrl . '/viewinvoice.php?id=' . $invoiceId;
	$paygatedotto_eurcsol_currency = $params['currency'];
	$callback_URL = $redirectUrl . '?invoice_id=' . $invoiceId;

		
$paygatedotto_eurcsol_response = file_get_contents('https://api.paygate.to/crypto/sol/eurc/convert.php?value=' . $amount . '&from=' . strtolower($paygatedotto_eurcsol_currency));


$paygatedotto_eurcsol_conversion_resp = json_decode($paygatedotto_eurcsol_response, true);

if ($paygatedotto_eurcsol_conversion_resp && isset($paygatedotto_eurcsol_conversion_resp['value_coin'])) {
    // Escape output
    $paygatedotto_eurcsol_final_total = $paygatedotto_eurcsol_conversion_resp['value_coin'];      
} else {
	return "Error: Payment could not be processed, please try again (unsupported store currency)";
}	
		
		if ($params['blockchain_fees'] === 'on') {
			
	$paygatedotto_eurcsol_blockchain_response = file_get_contents('https://api.paygate.to/crypto/sol/eurc/fees.php');


$paygatedotto_eurcsol_blockchain_conversion_resp = json_decode($paygatedotto_eurcsol_blockchain_response, true);

if ($paygatedotto_eurcsol_blockchain_conversion_resp && isset($paygatedotto_eurcsol_blockchain_conversion_resp['estimated_cost_currency']['USD'])) {
    
	// revert blockchain fees back to ticker price
$paygatedotto_feerevert_eurcsol_response = file_get_contents('https://api.paygate.to/crypto/sol/eurc/convert.php?value=' . $paygatedotto_eurcsol_blockchain_conversion_resp['estimated_cost_currency']['USD'] . '&from=usd');


$paygatedotto_feerevert_eurcsol_conversion_resp = json_decode($paygatedotto_feerevert_eurcsol_response, true);

if ($paygatedotto_feerevert_eurcsol_conversion_resp && isset($paygatedotto_feerevert_eurcsol_conversion_resp['value_coin'])) {
    // Escape output
    $paygatedotto_feerevert_eurcsol_final_total = $paygatedotto_feerevert_eurcsol_conversion_resp['value_coin']; 
// output
    $paygatedotto_eurcsol_blockchain_final_total = $paygatedotto_feerevert_eurcsol_final_total; 	
} else {
	return "Error: Payment could not be processed, please try again (unable to get estimated cost)";
}
     
} else {
	return "Error: Payment could not be processed, estimated blockchain cost unavailable";
}	

    $paygatedotto_eurcsol_amount_to_send = $paygatedotto_eurcsol_final_total + $paygatedotto_eurcsol_blockchain_final_total;		
	
		} else {
	$paygatedotto_eurcsol_amount_to_send = $paygatedotto_eurcsol_final_total;		
		}
		
		
		
$paygatedotto_eurcsol_gen_wallet = file_get_contents('https://api.paygate.to/crypto/sol/eurc/wallet.php?address=' . $walletAddress .'&callback=' . urlencode($callback_URL));


	$paygatedotto_eurcsol_wallet_decbody = json_decode($paygatedotto_eurcsol_gen_wallet, true);

 // Check if decoding was successful
    if ($paygatedotto_eurcsol_wallet_decbody && isset($paygatedotto_eurcsol_wallet_decbody['address_in'])) {
        // Store the address_in as a variable
        $paygatedotto_eurcsol_gen_addressIn = $paygatedotto_eurcsol_wallet_decbody['address_in'];
		$paygatedotto_eurcsol_gen_callback = $paygatedotto_eurcsol_wallet_decbody['callback_url'];
		
		$paygatedotto_jsonObject = json_encode(array(
'pay_to_address' => $paygatedotto_eurcsol_gen_addressIn,
'crypto_amount_to_send' => $paygatedotto_eurcsol_amount_to_send,
'coin_to_send' => 'sol_eurc'
));

		
		 // Update the invoice description to include address_in
            $invoiceDescription = $paygatedotto_jsonObject;

            // Update the invoice with the new description
            $invoice = localAPI("GetInvoice", array('invoiceid' => $invoiceId), null);
            $invoice['notes'] = $invoiceDescription;
            localAPI("UpdateInvoice", $invoice);

		
		
    } else {
return "Error: Payment could not be processed, please try again (wallet address error)";
    }
	
	
        $paygatedotto_eurcsol_gen_qrcode = file_get_contents('https://api.paygate.to/crypto/sol/eurc/qrcode.php?address=' . $paygatedotto_eurcsol_gen_addressIn);


	$paygatedotto_eurcsol_qrcode_decbody = json_decode($paygatedotto_eurcsol_gen_qrcode, true);

 // Check if decoding was successful
    if ($paygatedotto_eurcsol_qrcode_decbody && isset($paygatedotto_eurcsol_qrcode_decbody['qr_code'])) {
        // Store the qr_code as a variable
        $paygatedotto_eurcsol_gen_qrcode = $paygatedotto_eurcsol_qrcode_decbody['qr_code'];		
    } else {
return "Error: QR code could not be processed, please try again (wallet address error)";
    }

        // Properly encode attributes for HTML output
        return '<div><img src="data:image/png;base64,' . $paygatedotto_eurcsol_gen_qrcode . '" alt="' . $paygatedotto_eurcsol_gen_addressIn . '"></div><div>Please send <b>' . $paygatedotto_eurcsol_amount_to_send . '</b> sol/eurc to the address: <br><b>' . $paygatedotto_eurcsol_gen_addressIn . '</b></div>';
}

function eurcsol_activate()
{
    // You can customize activation logic if needed
    return array('status' => 'success', 'description' => 'eurcsol gateway activated successfully.');
}

function eurcsol_deactivate()
{
    // You can customize deactivation logic if needed
    return array('status' => 'success', 'description' => 'eurcsol gateway deactivated successfully.');
}

function eurcsol_upgrade($vars)
{
    // You can customize upgrade logic if needed
}

function eurcsol_output($vars)
{
    // Output additional information if needed
}

function eurcsol_error($vars)
{
    // Handle errors if needed
}
